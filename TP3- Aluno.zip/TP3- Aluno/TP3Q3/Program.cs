﻿using System;

public class Jogador
{
    public string nome;
    public string foto;
    public DateTime data;
    public int id;
    public string times;

    public Jogador(string nome, int id, string foto, DateTime data, string times)
    {
        this.nome = nome;
        this.id = id;
        this.foto = foto;
        this.data = data;
        this.times = times;
    }
}

class Program
{
    static void Main(string[] args)
    {
        string dados = Console.ReadLine();

        Jogador[] todos = new Jogador[100];

        int conta = 0;

        while (dados != "FIM")
        {
            string[] dados1 = dados.Split('[', ']');
            string[] dados2 = dados1[0].Split(',');

            string nome = dados2[1].Trim();
            int id = int.Parse(dados2[5].Trim());
            string foto = dados2[2].Trim();
            DateTime data = DateTime.Parse(dados2[3].Trim());
            string times = dados1[1].Trim();

            Jogador j1 = new Jogador(nome, id, foto, data, times);

            todos[conta] = j1;

            conta++;

            dados = Console.ReadLine();
        }

        Selecao selecao = new Selecao(conta);
        selecao.MSort(todos);
        selecao.Mostrar(todos);
    }
}

class Selecao : Geracao
{
    public Selecao() : base()
    {
    }

    public Selecao(int tamanho) : base(tamanho)
    {
    }

    public void MSort(Jogador[] array)
    {
        Sort(array, 0, n - 1);
    }

    public void Sort(Jogador[] array, int esq, int dir)
    {
        if (esq < dir)
        {
            int meio = (esq + dir) / 2;
            Sort(array, esq, meio);
            Sort(array, meio + 1, dir);
            Intercalar(array, esq, meio, dir);
        }
    }

    public void Intercalar(Jogador[] array, int esq, int meio, int dir)
    {
        int n1 = meio - esq + 1;
        int n2 = dir - meio;

        Jogador[] a1 = new Jogador[n1];
        Jogador[] a2 = new Jogador[n2];

        for (int i = 0; i < n1; i++)
        {
            a1[i] = array[esq + i];
        }

        for (int j = 0; j < n2; j++)
        {
            a2[j] = array[meio + j + 1];
        }

        int k = esq;
        int idx1 = 0;
        int idx2 = 0;

        while (idx1 < n1 && idx2 < n2)
        {
            if (a1[idx1].data <= a2[idx2].data)
            {
                array[k] = a1[idx1];
                idx1++;
            }
            else
            {
                array[k] = a2[idx2];
                idx2++;
            }

            k++;
        }

        while (idx1 < n1)
        {
            array[k] = a1[idx1];
            idx1++;
            k++;
        }

        while (idx2 < n2)
        {
            array[k] = a2[idx2];

            idx2++;
            k++;
        }
    }
}

class Geracao
{
    protected Jogador[] array;
    protected int n;
    public Geracao()
{
    array = new Jogador[100];
    n = array.Length;
}

public Geracao(int tamanho)
{
    array = new Jogador[tamanho];
    n = array.Length;
}

public void Mostrar(Jogador[] array)
{
    for (int i = 0; i < n; i++)
    {
        Console.WriteLine(array[i].id + " " + array[i].nome + " " + array[i].data.ToString("d/MM/yyyy") + " " + array[i].foto + " " + "(" + array[i].times + ")");
    }
}
}