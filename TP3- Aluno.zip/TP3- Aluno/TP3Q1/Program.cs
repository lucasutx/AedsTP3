﻿using System;

public class Jogador
{
    public string nome;
    public string foto;
    public DateTime data;
    public int id;
    public string times;

    public Jogador(string nome, int id, string foto, DateTime data, string times)
    {
        this.nome = nome;
        this.id = id;
        this.foto = foto;
        this.data = data;
        this.times = times;
    }
}

class Program
{
    static void Main(string[] args)
    {
        string dados = Console.ReadLine();

        Jogador[] todos = new Jogador[100];

        int conta = 0;

        while (dados != "FIM")
        {
            string[] dados1 = dados.Split('[', ']');
            string[] dados2 = dados1[0].Split(',');

            string nome = dados2[1].Trim();
            int id = int.Parse(dados2[5].Trim());
            string foto = dados2[2].Trim();
            DateTime data = DateTime.Parse(dados2[3].Trim());
            string times = dados1[1].Trim();

            Jogador j1 = new Jogador(nome, id, foto, data, times);

            todos[conta] = j1;

            conta++;

            dados = Console.ReadLine();
        }

        Jogador[] atualizado = new Jogador[conta];

        for (int i = 0; i < atualizado.Length; i++)
        {
            atualizado[i] = todos[i];
        }

        Selecao selecao = new Selecao(conta);
        selecao.Sort(atualizado);
        selecao.Mostrar(atualizado);
    }
}

class Selecao
{
    private Geracao geracao;

    public Selecao(int tamanho)
    {
        geracao = new Geracao(tamanho);
    }

    public void Sort(Jogador[] array)
    {
        int tamanho = array.Length;

        for (int i = 0; i < tamanho - 1; i++)
        {
            int menor = i;
            for (int j = i + 1; j < tamanho; j++)
            {
                if (array[j].id < array[menor].id)
                {
                    menor = j;
                }
            }
            geracao.Swap(array, menor, i);
        }
    }

    public void Mostrar(Jogador[]atualizado)
    {
        geracao.Mostrar(atualizado);
    }
}

class Geracao
{
    protected Jogador[] array;
    protected int n;

    public Geracao(int tamanho)
    {
        array = new Jogador[tamanho];
        n = array.Length;
    }

    public void Swap(Jogador[] array, int i, int j)
    {
        Jogador temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    public void Mostrar(Jogador[] jogadores)
    {
        int tamanho = jogadores.Length;

        for (int i = 0; i < tamanho; i++)
        {
            Console.WriteLine(jogadores[i].id + " " + jogadores[i].nome + " " + jogadores[i].data.ToString("d/MM/yyyy") + " " + jogadores[i].foto + " " + "(" + jogadores[i].times + ")");
        }
    }
}
