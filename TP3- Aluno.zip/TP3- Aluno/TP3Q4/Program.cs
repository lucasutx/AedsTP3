﻿using System;

public class Jogador
{
    public string nome;
    public string foto;
    public DateTime data;
    public int id;
    public string times;

    public Jogador(string nome, int id, string foto, DateTime data, string times)
    {
        this.nome = nome;
        this.id = id;
        this.foto = foto;
        this.data = data;
        this.times = times;
    }
}

class Program
{
    static void Main(string[] args)
    {
        string dados = Console.ReadLine();

        Jogador[] todos = new Jogador[100];

        int conta = 0;

        while (dados != "FIM")
        {
            string[] dados1 = dados.Split('[', ']');
            string[] dados2 = dados1[0].Split(',');

            string nome = dados2[1];
            int id = int.Parse(dados2[5]);
            string foto = dados2[2];
            DateTime data = DateTime.Parse(dados2[3]);
            string times = dados1[1];

            Jogador j1 = new Jogador(nome, id, foto, data, times);

            todos[conta] = j1;

            conta++;

            dados = Console.ReadLine();
        }

        Jogador[] atualizado = new Jogador[conta];

        for (int i = 0; i < atualizado.Length; i++)
        {
            atualizado[i] = todos[i];
        }

        Selecao selecao = new Selecao(conta);

        selecao.Sort(atualizado);

        selecao.Mostrar(atualizado);

    }
}

class Geracao
{
    protected Jogador[] array;
    protected int n;

    public Geracao(int tamanho)
    {
        array = new Jogador[tamanho];
        n = array.Length;
    }

    protected void Swap(Jogador[] array, int i, int j)
    {
        Jogador temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    public void Mostrar(Jogador[] jogadores)
    {
        int tamanho = jogadores.Length;

        for (int i = 0; i < tamanho; i++)
        {
            Console.WriteLine(jogadores[i].id + " " + jogadores[i].nome + " " + jogadores[i].data.ToString("d/MM/yyyy") + " " + jogadores[i].foto + " " + "(" + jogadores[i].times + ")");
        }
    }
}

class Selecao : Geracao
{
    public Selecao(int tamanho) : base(tamanho)
    {
    }

    public void Sort(Jogador[] array)
    {
        SortQuicksort(0, n - 1, array);
    }

    private void SortQuicksort(int esq, int dir, Jogador[] array)
    {
        int i = esq, j = dir;
        Jogador pivo = array[(dir + esq) / 2];

        while (i <= j)
        {
            while (string.Compare(array[i].nome, pivo.nome) < 0)
                i++;
            while (string.Compare(array[j].nome, pivo.nome) > 0)
                j--;
            if (i <= j)
            {
                Swap(array, i, j);
                i++;
                j--;
            }
        }

        
        if (esq < j)
            SortQuicksort(esq, j, array);
        if (i < dir)
            SortQuicksort(i, dir, array);
    }
}