﻿using System;

public class Jogador
{
    public string nome;
    public string foto;
    public DateTime data;
    public int id;
    public string times;

    public Jogador(string nome, int id, string foto, DateTime data, string times)
    {
        this.nome = nome;
        this.id = id;
        this.foto = foto;
        this.data = data;
        this.times = times;
    }
}

class Program
{
    static void Main(string[] args)
    {
        string dados = Console.ReadLine();

        Jogador[] todos = new Jogador[100];

        int conta = 0;

        while (dados != "FIM")
        {
            string[] dados1 = dados.Split('[', ']');
            string[] dados2 = dados1[0].Split(',');

            string nome = dados2[1];
            int id = int.Parse(dados2[5]);
            string foto = dados2[2];
            DateTime data = DateTime.Parse(dados2[3]);
            string times = dados1[1];

            Jogador j1 = new Jogador(nome, id, foto, data, times);

            todos[conta] = j1;

            conta++;

            dados = Console.ReadLine();
        }

        Selecao selecao = new Selecao(conta);
        selecao.Sort(todos);
        
    }
}

class Selecao : Geracao
{
    public Selecao() : base()
    {
    }

    public Selecao(int tamanho) : base(tamanho)
    {
    }

    public void Sort(Jogador[] array)
    {
        for (int i = 1; i < n; i++)
        {
            Jogador tmp = array[i];
            int j = i - 1;

            while ((j >= 0) && (array[j].id > tmp.id))
            {
                array[j + 1] = array[j];
                j--;
            }

            array[j + 1] = tmp;
        }

        Mostrar(array);
    }
}

class Geracao
{
    protected Jogador[] array;
    protected int n;

    public Geracao()
    {
        array = new Jogador[100];
        n = array.Length;
    }

    public Geracao(int tamanho)
    {
        array = new Jogador[tamanho];
        n = array.Length;
    }

    public void Mostrar(Jogador[] array)
    {
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine(array[i].id + " " + array[i].nome + " " + array[i].data.ToString("d/MM/yyyy") + " " + array[i].foto + " " + "(" + array[i].times + ")");
        }
    }
}